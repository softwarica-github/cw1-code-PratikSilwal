from tkinter import *
from tkinter import messagebox


class Login:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Record System", )
        self.root.geometry("1350x700+0+0")
        self.root.configure(bg="darkslateblue")

        # inserting login box
        F1 = Frame(self.root, bd=10, bg="lightyellow", relief=GROOVE)
        F1.place(x=450, y=150, height=350)

        self.user = StringVar()
        self.password = StringVar()

        title = Label(F1, text="Login System", bg="lightyellow", font=("times new roman", 30, "bold")).grid(row=0,
                                                                                                            columnspan=2,
                                                                                                            pady=20)

        # adding username field in login box
        lblusername = Label(F1, text="Username", bg="lightyellow", font=("times new roman", 25, "bold")).grid(row=1,
                                                                                                              column=0,
                                                                                                              pady=10,
                                                                                                              padx=10)
        txtuser = Entry(F1, bd=7, relief=GROOVE, textvariable=self.user, width=25, font="Ariel 15 bold").grid(row=1,
                                                                                                              column=1,
                                                                                                              padx=10,
                                                                                                              pady=10)

        # adding password field in login box
        lblpass = Label(F1, text="Password", bg="lightyellow", font=("times new roman", 25, "bold")).grid(row=2,
                                                                                                          column=0,
                                                                                                          pady=10,
                                                                                                          padx=10)
        txtpass = Entry(F1, bd=7, relief=GROOVE, show="*", textvariable=self.password, width=25,
                        font="Ariel 15 bold").grid(row=2, column=1, padx=10, pady=10)

        btnlog = Button(F1, text="Login", font="Ariel 15 bold", bd=7, bg="lightgreen", width=10,
                        command=self.loginfunction).place(x=10, y=250)
        btnreset = Button(F1, text="Reset", font="Ariel 15 bold", bd=7, bg="lightgreen", width=10,
                          command=self.reset).place(x=165, y=250)
        btnexit = Button(F1, text="Exit", font="Ariel 15 bold", bd=7, bg="lightgreen", width=10,
                         command=self.exitfun).place(x=320, y=250)

    def loginfunction(self):
        if self.user.get() == "Admin" and self.password.get() == "Admin":
            self.root.destroy()
            import software
            software.File_App()

        else:
            messagebox.showerror("Error", "Invalid username or password")

    def reset(self):
        self.user.set("")
        self.password.set("")

    def exitfun(self):
        option = messagebox.askyesno("Exit", "Are you sure you want to exit?")
        if option > 0:
            self.root.destroy()
        else:
            return


root = Tk()
ob = Login(root)
root.mainloop()
